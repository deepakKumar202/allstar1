import 'package:flutter/material.dart';

class EventDatail extends StatefulWidget {
  const EventDatail({super.key});

  @override
  State<EventDatail> createState() => _EventDatailState();
}

class _EventDatailState extends State<EventDatail> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
       backgroundColor: const Color(0XFF04080F),
      appBar: AppBar(
        elevation: 0.0,
        centerTitle: true,
        backgroundColor: const Color(0XFF04080F),
        leading: IconButton(onPressed: () {}, icon: const Icon(Icons.home)),
        title: const Text(
          "EVENT DETAILS",
          style: TextStyle(
              color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 15),
            child: IconButton(
                onPressed: () {}, icon: const Icon(Icons.notifications)),
          ),
        ],
      ),
      body: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Column(),
      ),
    );
  }
}
