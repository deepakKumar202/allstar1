import 'package:flutter/material.dart';

class Tickets_Page extends StatefulWidget {
  const Tickets_Page({super.key});

  @override
  State<Tickets_Page> createState() => _Tickets_PageState();
}

class _Tickets_PageState extends State<Tickets_Page> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0XFF04080F),
      appBar: AppBar(
        elevation: 0.0,
        centerTitle: true,
        backgroundColor: const Color(0XFF04080F),
        leading: IconButton(onPressed: () {}, icon: const Icon(Icons.home)),
        title: const Text(
          "TICKETS",
          style: TextStyle(
              color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 15),
            child: IconButton(
                onPressed: () {}, icon: const Icon(Icons.notifications)),
          ),
        ],
      ),
      body: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
          child: Column(
            children: [
              Container(
                height: 45,
                width: double.infinity,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: const Color(0XFF202123),
                ),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Row(
                    children: const [
                      Icon(
                        Icons.search,
                        color: Color(0XFF45464A),
                      ),
                      SizedBox(width: 10),
                      Text(
                        "Search for Events",
                        style: TextStyle(color: Color(0xFF515357)),
                      )
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: const [
                  Text(
                    "Upcoming Near You",
                    style: TextStyle(
                        color: Color(0XFFCFCFCF),
                        fontSize: 22,
                        fontWeight: FontWeight.w700),
                  ),
                  Text(
                    "See of",
                    style: TextStyle(
                        color: Color(0XFF27292B),
                        fontSize: 18,
                        fontWeight: FontWeight.w700),
                  )
                ],
              ),
              Column(
                children: [
                  for (var i = 0; i < 10; i++)
                    Container(
                      height: MediaQuery.of(context).size.height * 0.1,
                      width: double.infinity,
                      decoration: const BoxDecoration(
                          // color: Colors.red,
                          ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                margin:
                                    const EdgeInsets.symmetric(horizontal: 0),
                                height: 60,
                                width: 60,
                                decoration: BoxDecoration(
                                    color: Colors.green,
                                    image: const DecorationImage(
                                        fit: BoxFit.cover,
                                        image: AssetImage('images/1.png')),
                                    borderRadius: BorderRadius.circular(10)),
                              ),
                              const SizedBox(width: 10),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: const [
                                      Icon(
                                        Icons.location_on,
                                        size: 15,
                                        color: Color(0xFF3C404F),
                                      ),
                                      Text(
                                        "5.5 mils",
                                        style: TextStyle(
                                            color: Color(0XFF4283B3),
                                            fontSize: 10),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 5),
                                  const Text(
                                    "NETS V. Bucks",
                                    style: TextStyle(
                                        color: Color(0XFFD3D3D3),
                                        fontWeight: FontWeight.bold),
                                  ),
                                  const SizedBox(height: 5),
                                  Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: const [
                                      Text(
                                        "10/22/2022",
                                        style: TextStyle(
                                            color: Color(0XFF313335),
                                            fontSize: 10),
                                      ),
                                      SizedBox(width: 5),
                                      Text(
                                        "@",
                                        style: TextStyle(
                                            color: Color(0XFF313335),
                                            fontSize: 10),
                                      ),
                                      SizedBox(width: 5),
                                      Text(
                                        "10pm",
                                        style: TextStyle(
                                            color: Color(0XFF313335),
                                            fontSize: 10),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                              const SizedBox(width: 116),
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: const [
                                  Icon(
                                    Icons.star,
                                    color: Color(0xFFFFA235),
                                    size: 15,
                                  ),
                                  SizedBox(width: 5),
                                  Text(
                                    "4.9",
                                    style: TextStyle(
                                        color: Color(0XFF313335), fontSize: 14),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
