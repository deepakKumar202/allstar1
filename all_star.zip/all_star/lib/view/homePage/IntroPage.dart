import 'package:all_star/bottom_navigation/Bottom_bar.dart';
import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: const Color(0xff000000),
        body: SafeArea(
          child: SingleChildScrollView(
            scrollDirection: Axis.vertical,
            child: Column(
              children: [
                const SizedBox(height: 80),
                const CircleAvatar(
                  radius: 120,
                ),
                const SizedBox(
                  height: 50,
                ),
                InkWell(
                  onTap: () {},
                  child: Container(
                    margin: const EdgeInsets.symmetric(
                        horizontal: 20, vertical: 20),
                    width: double.infinity,
                    height: MediaQuery.of(context).size.height * 0.4,
                    decoration: BoxDecoration(
                        color: const Color(0XFF1D2127),
                        borderRadius: BorderRadius.circular(25)),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          vertical: 15, horizontal: 10),
                      child: Column(
                        // mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          const Text(
                            "Welcome to All Star",
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 22,
                                fontWeight: FontWeight.bold),
                          ),
                          const Text(
                            "Seating Navigation",
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 22,
                                fontWeight: FontWeight.bold),
                          ),
                          const SizedBox(height: 20),
                          const Text(
                            "A premimum experience allowing you to navigate",
                            style: TextStyle(color: Color(0XFF7F8184)),
                          ),
                          const Text(
                            "your next stadium visit with pass and share",
                            style: TextStyle(color: Color(0XFF7F8184)),
                          ),
                          const Text(
                            "Your moments with family & friends",
                            style: TextStyle(color: Color(0XFF7F8184)),
                          ),
                          const SizedBox(height: 10),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: const [
                              CircleAvatar(
                                backgroundColor: Colors.white,
                                radius: 4,
                              ),
                              SizedBox(width: 5),
                              CircleAvatar(
                                backgroundColor: Colors.grey,
                                radius: 3,
                              ),
                              SizedBox(width: 5),
                              CircleAvatar(
                                backgroundColor: Colors.grey,
                                radius: 3,
                              ),
                            ],
                          ),
                          InkWell(
                            onTap: () {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => BottomBarrr()));
                            },
                            child: Container(
                              alignment: Alignment.center,
                              width: double.infinity,
                              margin: const EdgeInsets.only(top: 70),
                              height: 45,
                              decoration: BoxDecoration(
                                  color: const Color(0XFF61D0CA),
                                  borderRadius: BorderRadius.circular(10)),
                              child: const Text(
                                "Next",
                                style: TextStyle(
                                    color: Color(0XFFC4EDEB),
                                    fontSize: 16,
                                    fontWeight: FontWeight.w600),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                )
              ],
            ),
          ),
        ));
  }
}
