import 'package:all_star/view/navigationn/navigation2.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class Navigationn extends StatefulWidget {
  const Navigationn({super.key});

  @override
  State<Navigationn> createState() => _NavigationnState();
}

class _NavigationnState extends State<Navigationn> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0XFF04080F),
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: const Color(0XFF04080F),
        leading: IconButton(
            onPressed: () {},
            icon: const Icon(
              Icons.remove,
              color: Color(0XFF4F5257),
            )),
        title: const Text(
          "Navigation",
          style: TextStyle(
              color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
        ),
        actions: const [
          Padding(
            padding: EdgeInsets.only(right: 15),
            child: Icon(
              Icons.close,
              color: Color(0XFF838383),
              size: 18,
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
          child: Column(
            children: [
              Container(
                height: MediaQuery.of(context).size.height * 0.4,
                width: double.infinity,
                decoration: BoxDecoration(
                    color: const Color(0XFFEAECF2),
                    borderRadius: BorderRadius.circular(25)),
              ),
              const SizedBox(height: 5),
              const Text(
                "dsh shbs shbfshfb sjdh dkd sahf",
                style: TextStyle(color: Color(0XFFAAACAE), fontSize: 12),
              ),
              const SizedBox(height: 40),
              Column(
                // mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: const [
                  Text(
                    "How to Navigate?",
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 22,
                        fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 20),
                  Text(
                    "Make your position on the Map and click",
                    style: TextStyle(color: Color(0XFF7F8184)),
                  ),
                  Text(
                    "Navigate to have the app ganarate",
                    style: TextStyle(color: Color(0XFF7F8184)),
                  ),
                  Text(
                    "Navigation instrucations",
                    style: TextStyle(color: Color(0XFF7F8184)),
                  ),
                  SizedBox(height: 10),
                ],
              ),
              const SizedBox(height: 15),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Column(
                    children: [
                      Container(
                        alignment: Alignment.center,
                        height: 60,
                        width: 60,
                        decoration: BoxDecoration(
                            color: const Color(0XFF000000),
                            borderRadius: BorderRadius.circular(10)),
                        child: const Icon(
                          Icons.navigation,
                          color: Color(0XFF7BD061),
                        ),
                      ),
                      const SizedBox(height: 5),
                      const Text(
                        "Navigate",
                        style: TextStyle(color: Color(0XFF51555D)),
                      )
                    ],
                  ),
                  Column(
                    children: [
                      Container(
                        alignment: Alignment.center,
                        height: 60,
                        width: 60,
                        decoration: BoxDecoration(
                            color: const Color(0XFF000000),
                            borderRadius: BorderRadius.circular(10)),
                        child: const Icon(
                          Icons.share_location,
                          color: Color(0XFF61C7D0),
                        ),
                      ),
                      const SizedBox(height: 5),
                      const Text(
                        "Share location",
                        style:
                            TextStyle(color: Color(0XFF51555D), fontSize: 12),
                      )
                    ],
                  ),
                  Column(
                    children: [
                      Container(
                        alignment: Alignment.center,
                        height: 60,
                        width: 60,
                        decoration: BoxDecoration(
                            color: const Color(0XFF000000),
                            borderRadius: BorderRadius.circular(10)),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: const [
                            Icon(
                              Icons.call,
                              color: Color(0XFF616ED0),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 5),
                      const Text(
                        "Call vanue",
                        style: TextStyle(color: Color(0XFF51555D)),
                      )
                    ],
                  )
                ],
              ),
              const SizedBox(height: 10),
              Container(
                alignment: Alignment.center,
                height: MediaQuery.of(context).size.height * 0.1,
                width: double.infinity,
                decoration: BoxDecoration(
                  color: const Color(0xFF1D2127),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    InkWell(
                      onTap: () {
                        Get.to(const Navigationn2());
                      },
                      child: Container(
                        alignment: Alignment.center,
                        margin: const EdgeInsets.symmetric(horizontal: 10),
                        height: 45,
                        width: double.infinity,
                        decoration: BoxDecoration(
                          color: const Color(0xFF61D0CA),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Text(
                          "Open In Apple Wallet",
                          style:
                              TextStyle(color: Color(0XFFD7F3F2), fontSize: 18),
                        ),
                      ),
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
