// // ignore: file_names
// // ignore: file_names
// import 'package:all_star/view/homePage/HomePage2.dart';
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:fluttertoast/fluttertoast.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';

// import '../model_page/SignupUserModel.dart';

// class SignupPage extends StatefulWidget {
//   const SignupPage({super.key});

//   @override
//   State<SignupPage> createState() => _SignupPageState();
// }

// class _SignupPageState extends State<SignupPage> {
//   TextEditingController nameController = TextEditingController();
//   TextEditingController emailController = TextEditingController();
//   TextEditingController passController = TextEditingController();
//   TextEditingController confirPassController = TextEditingController();
//   GlobalKey<FormState> globalKey = GlobalKey<FormState>();
//   final _auth = FirebaseAuth.instance;

//   //  void signUp(String email, String password) async {
//   //   if (globalKey.currentState!.validate()) {
//   //     await _auth
//   //         .createUserWithEmailAndPassword(email: email, password: password)
//   //         .then((value) => {})
//   //         .catchError((e) {
//   //   Fluttertoast.showToast(
//   //       msg: "This is Center Short Toast",
//   //       toastLength: Toast.LENGTH_SHORT,
//   //       gravity: ToastGravity.CENTER,
//   //       timeInSecForIosWeb: 1,
//   //       backgroundColor: Colors.red,
//   //       textColor: Colors.white,
//   //       fontSize: 16.0);
//   // });
//   //   }
//   // }

//   // postDetailsToFirestore() async {
//   //   FirebaseFirestore firebaseFirestore = FirebaseFirestore.instance;
//   //   User? user = _auth.currentUser;
//   //   UserModel userModel = UserModel();
//   //   userModel.emaill =  user!.email;
//   //   userModel.uid = user.uid;
//   //   userModel.name = nameController.text;
//   //   userModel.emaill = emailController.text;
//   //   userModel.pass = passController.text;
//   //   userModel.confii = confirPassController.text;
//   // }
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: const Color(0XFF04080F),
//       appBar: AppBar(
//         backgroundColor: const Color(0XFF04080F),
//         elevation: 0.0,
//         leading: InkWell(
//           onTap: () {
//             Get.back();
//           },
//           child: Container(
//             margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 8),
//             height: 35,
//             width: 35,
//             decoration: BoxDecoration(
//               borderRadius: BorderRadius.circular(10),
//               color: const Color(0XFF61D0CA),
//             ),
//             child: const Icon(Icons.arrow_back_ios),
//           ),
//         ),
//       ),
//       body: SingleChildScrollView(
//         scrollDirection: Axis.vertical,
//         child: Padding(
//           padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
//           child: Column(
//             mainAxisAlignment: MainAxisAlignment.center,
//             crossAxisAlignment: CrossAxisAlignment.center,
//             children: [
//               Padding(
//                 padding:
//                     const EdgeInsets.symmetric(horizontal: 60, vertical: 10),
//                 child: Container(
//                   height: MediaQuery.of(context).size.height * 0.3,
//                   width: double.infinity,
//                   decoration: BoxDecoration(
//                       color: const Color(0XFF1D2127),
//                       borderRadius: BorderRadius.circular(20)),
//                 ),
//               ),
//               const SizedBox(height: 25),
//               const Text(
//                 "Sign In",
//                 style: TextStyle(
//                     color: Color(0XFFD2D2D2),
//                     fontSize: 42,
//                     fontWeight: FontWeight.bold),
//               ),
//               const SizedBox(height: 20),
//               Row(
//                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                 children: [
//                   signInwith_Google(),
//                   fecebookk(),
//                   twiterr(),
//                 ],
//               ),
//               const SizedBox(height: 20),
//               Form(
//                 key: globalKey,
//                 child: Column(
//                   children: [
//                     Container(
//                       decoration: BoxDecoration(
//                           color: const Color(0XFF12110E),
//                           borderRadius: BorderRadius.circular(25)),
//                       child: TextFormField(
//                         controller: nameController,
//                         validator: (value) {
//                           if (value == null || value.isEmpty) {
//                             return "Plese Enter Your UserName";
//                           }
//                           return null;
//                         },
//                         decoration: const InputDecoration(
//                           border:
//                               OutlineInputBorder(borderSide: BorderSide.none),
//                           contentPadding: EdgeInsets.symmetric(horizontal: 10),
//                           hintText: "username",
//                           hintStyle: TextStyle(
//                               fontSize: 14,
//                               color: Colors.white,
//                               fontWeight: FontWeight.w600),
//                         ),
//                       ),
//                     ),
//                     const SizedBox(height: 10),
//                     Container(
//                       decoration: BoxDecoration(
//                           color: const Color(0XFF12110E),
//                           borderRadius: BorderRadius.circular(25)),
//                       child: TextFormField(
//                         controller: emailController,
//                         validator: (value) {
//                           if (value == null || value.isEmpty) {
//                             return "Plese Enter Your Email";
//                           }
//                           return null;
//                         },
//                         decoration: const InputDecoration(
//                           border:
//                               OutlineInputBorder(borderSide: BorderSide.none),
//                           contentPadding: EdgeInsets.symmetric(horizontal: 10),
//                           hintText: "Your Email",
//                           hintStyle: TextStyle(
//                               fontSize: 14,
//                               fontWeight: FontWeight.w600,
//                               color: Colors.white),
//                         ),
//                       ),
//                     ),
//                     const SizedBox(height: 10),
//                     Container(
//                       decoration: BoxDecoration(
//                           color: const Color(0XFF12110E),
//                           borderRadius: BorderRadius.circular(25)),
//                       child: TextFormField(
//                         controller: passController,
//                         validator: (value) {
//                           if (value == null || value.isEmpty) {
//                             return "Plese Enter Your password";
//                           }
//                           return null;
//                         },
//                         decoration: const InputDecoration(
//                           border:
//                               OutlineInputBorder(borderSide: BorderSide.none),
//                           contentPadding: EdgeInsets.symmetric(horizontal: 10),
//                           hintText: "Your password",
//                           hintStyle: TextStyle(
//                               fontSize: 14, fontWeight: FontWeight.w600),
//                         ),
//                       ),
//                     ),
//                     const SizedBox(height: 10),
//                     Container(
//                       height: 45,
//                       width: double.infinity,
//                       decoration: BoxDecoration(
//                         borderRadius: BorderRadius.circular(25),
//                         color: const Color(0XFF12110E),
//                       ),
//                       child: Row(
//                         children: [
//                           Container(
//                             height: 45,
//                             width: MediaQuery.of(context).size.width * 0.6,
//                             decoration: BoxDecoration(
//                                 color: const Color(0XFF12110E),
//                                 borderRadius: BorderRadius.circular(25)),
//                             child: TextFormField(
//                               controller: confirPassController,
//                               validator: (value) {
//                                 if (value == null || value.isEmpty) {
//                                   return "Plese Enter confirmPassword";
//                                 }
//                                 return null;
//                               },
//                               decoration: const InputDecoration(
//                                 border: OutlineInputBorder(
//                                     borderSide: BorderSide.none),
//                                 contentPadding:
//                                     EdgeInsets.symmetric(horizontal: 10),
//                                 hintText: "confirm Password",
//                                 hintStyle: TextStyle(
//                                     fontSize: 14, fontWeight: FontWeight.w600),
//                               ),
//                             ),
//                           ),
//                           Container(
//                             alignment: Alignment.center,
//                             height: 45,
//                             width: MediaQuery.of(context).size.width * 0.3,
//                             decoration: const BoxDecoration(
//                                 // color: Colors.yellow,
//                                 ),
//                             child: const Text(
//                               "Confirm Password",
//                               style: TextStyle(
//                                 color: Color(0XFFD2F2F0),
//                                 fontWeight: FontWeight.bold,
//                               ),
//                             ),
//                           )
//                         ],
//                       ),
//                     ),
//                     const SizedBox(height: 30),
//                     const Text(
//                       "or with email?",
//                       style: TextStyle(
//                           color: Color(0XFFD2F2F0),
//                           fontWeight: FontWeight.bold),
//                     ),
//                     const SizedBox(height: 30),
//                     InkWell(
//                       onTap: () {
//                         if (globalKey.currentState!.validate()) {
//                           _auth
//                               .createUserWithEmailAndPassword(
//                                   email: emailController.text.toString(),
//                                   password: passController.text.toString())
//                               .then((value) {})
//                               .onError((error, stackTrace) {});
//                           Get.to(const HomePage2());
//                         }
//                       },
//                       child: Container(
//                         alignment: Alignment.center,
//                         height: 45,
//                         width: double.infinity,
//                         decoration: BoxDecoration(
//                             borderRadius: BorderRadius.circular(25),
//                             color: const Color(0XFF61D0CA)),
//                         child: const Text(
//                           "Sign Up",
//                           style: TextStyle(
//                               color: Color(0XFFD2F2F0),
//                               fontWeight: FontWeight.bold,
//                               fontSize: 18),
//                         ),
//                       ),
//                     )
//                   ],
//                 ),
//               )
//             ],
//           ),
//         ),
//       ),
//     );
//   }

//   // ignore: non_constant_identifier_names
//   signInwith_Google() {
//     return Container(
//       height: 45,
//       width: MediaQuery.of(context).size.width * 0.6,
//       decoration: BoxDecoration(
//         color: const Color(0XFFEB91E8),
//         borderRadius: BorderRadius.circular(25),
//       ),
//       child: Row(
//         mainAxisAlignment: MainAxisAlignment.center,
//         children: [
//           Image.asset(
//             'images/google.png',
//             width: 25,
//             height: 25,
//           ),
//           const SizedBox(width: 10),
//           const Text(
//             "Sign In With Google",
//             style: TextStyle(
//                 color: Color(0XFFF9DDF8),
//                 fontSize: 14,
//                 fontWeight: FontWeight.w600),
//           ),
//         ],
//       ),
//     );
//   }

//   fecebookk() {
//     return Container(
//       height: 45,
//       width: 45,
//       decoration: BoxDecoration(
//           image:
//               const DecorationImage(image: AssetImage('images/fecebook.png')),
//           borderRadius: BorderRadius.circular(25),
//           border: Border.all(color: const Color(0XFF1A1B15)),
//           color: const Color(0XFF151411)),
//     );
//   }

//   twiterr() {
//     return Container(
//       height: 45,
//       width: 45,
//       decoration: BoxDecoration(
//           image: const DecorationImage(image: AssetImage('images/twiter.png')),
//           borderRadius: BorderRadius.circular(25),
//           border: Border.all(color: const Color(0XFF1A1B15)),
//           color: const Color(0XFF151411)),
//     );
//   }
// }
