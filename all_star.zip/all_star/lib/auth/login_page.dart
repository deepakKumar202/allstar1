import 'package:all_star/controller/googllogincontroller.dart';
import 'package:flutter/material.dart';
// ignore: depend_on_referenced_packages
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  TextEditingController emailController = TextEditingController();
  TextEditingController passController = TextEditingController();
  GlobalKey<FormState> globalKey = GlobalKey<FormState>();
  final FirebaseAuth _auth = FirebaseAuth.instance;
  LoginController controller = LoginController();

  // googleLogin() async {
  //   print("googleLogin method callded");
  //   GoogleSignIn googlesignin = GoogleSignIn();
  //   try {
  //     var result = await googlesignin.signIn();
  //     if (result == null) {
  //       return;
  //     }
  //     final userData = await result.authentication;
  //     final credential = GoogleAuthProvider.credential(
  //         accessToken: userData.accessToken, idToken: userData.idToken);
  //     var finalResult =
  //         await FirebaseAuth.instance.signInWithCredential(credential);
  //     print("Result $result");
  //     print(result.displayName);
  //     print(result.email);
  //     print(result.photoUrl);
  //   } catch (error) {
  //     print(error);
  //   }
  // }

  Future<void> logout() async {
    await GoogleSignIn().disconnect();
    FirebaseAuth.instance.signOut();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0XFF04080F),
      appBar: AppBar(
        backgroundColor: const Color(0XFF04080F),
        elevation: 0.0,
        leading: Container(
          margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 8),
          height: 35,
          width: 35,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            color: const Color(0XFF61D0CA),
          ),
          child: const Icon(Icons.arrow_back_ios),
        ),
        actions: [
          Padding(
              padding: const EdgeInsets.only(top: 20, right: 10),
              child: TextButton(
                onPressed: () {},
                child: const Text(
                  "Sign UP",
                  style: TextStyle(
                      color: Color(0XFFD9D9D9),
                      fontSize: 18,
                      fontWeight: FontWeight.w700),
                ),
              )),
        ],
      ),
      body: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
          child: Form(
            key: globalKey,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 60, vertical: 10),
                  child: Container(
                    height: MediaQuery.of(context).size.height * 0.3,
                    width: double.infinity,
                    decoration: BoxDecoration(
                        color: const Color(0XFF1D2127),
                        borderRadius: BorderRadius.circular(20)),
                  ),
                ),
                const SizedBox(height: 25),
                const Text(
                  "Sign In",
                  style: TextStyle(
                      color: Color(0XFFD2D2D2),
                      fontSize: 42,
                      fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    InkWell(
                      onTap: () {
                        controller.loginWithGoogle();
                      },
                      child: Container(
                        height: 45,
                        width: MediaQuery.of(context).size.width * 0.6,
                        decoration: BoxDecoration(
                          color: const Color(0XFFEB91E8),
                          borderRadius: BorderRadius.circular(25),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Image.asset(
                              'images/google.png',
                              width: 25,
                              height: 25,
                            ),
                            const SizedBox(width: 10),
                            const Text(
                              "Sign In With Google",
                              style: TextStyle(
                                  color: Color(0XFFF9DDF8),
                                  fontSize: 14,
                                  fontWeight: FontWeight.w600),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Container(
                      height: 45,
                      width: 45,
                      decoration: BoxDecoration(
                          image: const DecorationImage(
                              image: AssetImage('images/fecebook.png')),
                          borderRadius: BorderRadius.circular(25),
                          border: Border.all(color: const Color(0XFF1A1B15)),
                          color: const Color(0XFF151411)),
                    ),
                    Container(
                      height: 45,
                      width: 45,
                      decoration: BoxDecoration(
                          image: const DecorationImage(
                              image: AssetImage('images/fecebook.png')),
                          borderRadius: BorderRadius.circular(25),
                          border: Border.all(color: const Color(0XFF1A1B15)),
                          color: const Color(0XFF151411)),
                    ),
                    // fecebookk(),
                    // twiterr(),
                  ],
                ),
                const SizedBox(height: 20),
                Column(
                  children: [
                    Container(
                      decoration: BoxDecoration(
                          color: const Color(0XFF12110E),
                          borderRadius: BorderRadius.circular(25)),
                      child: TextFormField(
                        controller: emailController,
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return "Plese Enter Your Email";
                          }
                          return null;
                        },
                        decoration: const InputDecoration(
                          border:
                              OutlineInputBorder(borderSide: BorderSide.none),
                          fillColor: Colors.white,
                          contentPadding: EdgeInsets.symmetric(horizontal: 10),
                          hintText: "Your Email",
                          hintStyle: TextStyle(
                              fontSize: 14, fontWeight: FontWeight.w600),
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    Container(
                      height: 45,
                      width: double.infinity,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(25),
                        color: const Color(0XFF12110E),
                      ),
                      child: Row(
                        children: [
                          Container(
                            height: 45,
                            width: MediaQuery.of(context).size.width * 0.7,
                            decoration: BoxDecoration(
                                color: const Color(0XFF12110E),
                                borderRadius: BorderRadius.circular(25)),
                            child: TextFormField(
                              controller: passController,
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return "Plese Enter Password";
                                }
                                return null;
                              },
                              decoration: const InputDecoration(
                                border: OutlineInputBorder(
                                    borderSide: BorderSide.none),
                                contentPadding:
                                    EdgeInsets.symmetric(horizontal: 10),
                                fillColor: Colors.white,
                                hintText: "Password",
                                hintStyle: TextStyle(
                                    fontSize: 14, fontWeight: FontWeight.w600),
                              ),
                            ),
                          ),
                          InkWell(
                            onTap: () {
                              logout;
                            },
                            child: Container(
                              alignment: Alignment.center,
                              height: 45,
                              width: MediaQuery.of(context).size.width * 0.2,
                              decoration: const BoxDecoration(
                                  // color: Colors.yellow,
                                  ),
                              child: const Text(
                                "FORGET?",
                                style: TextStyle(
                                    color: Color(0XFFD2F2F0),
                                    fontWeight: FontWeight.bold),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                    const SizedBox(height: 30),
                    const Text(
                      "or with email?",
                      style: TextStyle(
                          color: Color(0XFFD2F2F0),
                          fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 30),
                    InkWell(
                      onTap: () {
                        if (globalKey.currentState!.validate()) {
                          _auth
                              .createUserWithEmailAndPassword(
                                  email: emailController.text.toString(),
                                  password: passController.text.toString())
                              .then((value) {})
                              .onError((error, stackTrace) {});
                          // Get.to(const SignupPage());
                        }
                      },
                      child: Container(
                        alignment: Alignment.center,
                        height: 45,
                        width: double.infinity,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(25),
                            color: const Color(0XFF61D0CA)),
                        child: const Text(
                          "Sign In",
                          style: TextStyle(
                              color: Color(0XFFD2F2F0),
                              fontWeight: FontWeight.bold,
                              fontSize: 18),
                        ),
                      ),
                    )
                  ],
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}


  // ignore: non_constant_identifier_names
  // signInwith_Google() {
  //   return Container(
  //     height: 45,
  //     width: MediaQuery.of(context).size.width * 0.6,
  //     decoration: BoxDecoration(
  //       color: const Color(0XFFEB91E8),
  //       borderRadius: BorderRadius.circular(25),
  //     ),
  //     child: Row(
  //       mainAxisAlignment: MainAxisAlignment.center,
  //       children: [
  //         Image.asset(
  //           'images/google.png',
  //           width: 25,
  //           height: 25,
  //         ),
  //         const SizedBox(width: 10),
  //         const Text(
  //           "Sign In With Google",
  //           style: TextStyle(
  //               color: Color(0XFFF9DDF8),
  //               fontSize: 14,
  //               fontWeight: FontWeight.w600),
  //         ),
  //       ],
  //     ),
  //   );
//   }

//   fecebookk() {
    // return Container(
    //   height: 45,
    //   width: 45,
    //   decoration: BoxDecoration(
    //       image:
    //           const DecorationImage(image: AssetImage('images/fecebook.png')),
    //       borderRadius: BorderRadius.circular(25),
    //       border: Border.all(color: const Color(0XFF1A1B15)),
    //       color: const Color(0XFF151411)),
    // );
//   }

//   twiterr() {
//     return Container(
//       height: 45,
//       width: 45,
//       decoration: BoxDecoration(
//           image: const DecorationImage(image: AssetImage('images/twiter.png')),
//           borderRadius: BorderRadius.circular(25),
//           border: Border.all(color: const Color(0XFF1A1B15)),
//           color: const Color(0XFF151411)),
//     );
//   }
// }
