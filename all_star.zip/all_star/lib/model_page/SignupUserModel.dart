// class UserModel{
//   String? uid;
//   String? emaill;
//   String? name;
//   String? pass;
//   String? confii;
//   UserModel({this.uid,this.emaill,this.name,this.pass,this.confii});
//   factory UserModel.fromMap(map)
//   {
//     return UserModel(
//       uid:map['uid'],
//       emaill: map['emaill'],
//       name: map['name'],
//       pass: map['pass'],
//       confii:map['confii'],
//     );
//   }
//   Map<String, dynamic> toMap(){
//     return{
//       'uid': uid,
//       'emaill': emaill,
//       'name': name,
//       'pass': pass,
//       'confii':confii,
//     };
//   }
// }