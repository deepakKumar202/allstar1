import 'package:all_star/view/homePage/HomePage2.dart';
import 'package:all_star/view/tickets/Tickets_Page.dart';
import 'package:flutter/material.dart';

class BottomBarrr extends StatefulWidget {
  @override
  _BottomBarrrState createState() => _BottomBarrrState();
}

class _BottomBarrrState extends State<BottomBarrr> {
  final bool _cheak = false;
  int _currentIndex = 0;
  static const TextStyle optionStyle =
      TextStyle(fontSize: 30, fontWeight: FontWeight.w500);
  final List<Widget> _children = [
    const HomePage2(),
    const Text("Page2"),
    const Text("Page3"),
    const Tickets_Page(),
    const Text("Page5")
  ];

  void onTabTapped(int index) {
    setState(() {
      _currentIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(child: _children[_currentIndex]),
      bottomNavigationBar: BottomNavigationBar(
        selectedItemColor: const Color(0XFF61D0CA),
        unselectedItemColor: const Color(0XFFDBDADB),
        backgroundColor: const Color(0XFF2B2D36),
        currentIndex: _currentIndex,
        onTap: onTabTapped,
        items: const [
          BottomNavigationBarItem(
            backgroundColor: Color(0XFF2B2D36),
            icon: Icon(
              Icons.home,
            ),
            label: '',
          ),
          BottomNavigationBarItem(
            backgroundColor: Color(0XFF2B2D36),
            icon: Icon(Icons.person_add),
            // activeIcon: Icon(Icons.person_add),
            // icon: Image(
            //   image: AssetImage(
            //     'images/mutual.png',
            //   ),
            //   color: Colors.white,
            // ),
            label: '',
          ),
          BottomNavigationBarItem(
            backgroundColor: Color(0XFF2B2D36),
            icon: Icon(Icons.location_on),
            label: '',
          ),
          BottomNavigationBarItem(
            backgroundColor: Color(0XFF2B2D36),
            icon: Icon(Icons.person),
            label: '',
          ),
          BottomNavigationBarItem(
            backgroundColor: Color(0XFF2B2D36),
            icon: Icon(Icons.settings),
            label: '',
          ),
        ],
      ),
    );
  }
}
