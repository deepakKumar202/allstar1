package com.example.all_star

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
